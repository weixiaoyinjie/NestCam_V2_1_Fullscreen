# NestCam V2.1 Fullscreen — 基于原版 V2 的轻改版（手机 / Watch 8）

- **连接方式完全沿用你上传的 V2**：不引入二维码/新配对流程，不改变 `/nestcam/v1/request`、`/nestcam/v1/response`、令牌以及手机中转逻辑。
- **手机全屏**：在原来的手机实时监控窗口内按「⛶ 全屏」，横屏沉浸式观看；按「退出全屏」或系统返回键恢复。全屏过程不重新发起 Nest API 或 WebRTC SDP，继续播放已有视频。
- **手表全屏**：在 Watch 8 预览图上点右上角「⛶」铺满圆形屏幕，点「↙」返回；使用相同 WebRTC 视频渲染器，切换不增加连接时间。铺满模式可能裁剪画面边缘。
- **视频接收提示**：接通首帧后自动隐藏状态提示；如果还没有视频，则显示连接状态而非纯黑屏。状态提示不能替代实际的网络排障。
- **Google Home 提醒/通知转发**：完整保留 V2 的开关、权限与警报逻辑。
- **构建**：ZIP 解压后把**所有文件和 `.github` 隐藏文件夹**上传至 GitHub 仓库根目录，Actions 中运行 `Build NestCam V2 Fullscreen (Phone + Watch8)`，分别下载两个 artifact。
- **安装与更新**：保持旧包名 `com.nestcam.watch8` 和原有本机私密配置的存储路径。若新旧 APK 使用同一签名，可直接覆盖更新；若签名不同，Android 会拒绝覆盖。GitHub Actions 每次重新产生的 debug keystore 不保证与之前的一致，**不能保证不卸载就能更新**；如发生签名不一致，须用原签名构建才能保留应用数据。不要清理现有凭据、不要在公开仓库上传 Client Secret。
- **验证说明**：未在真实 Nest 摄像头和 Galaxy Watch 8 上实测，也未在当前环境编译 APK；本 ZIP 包含可由 GitHub Actions 执行的构建配置，真实画面与连接速度须以设备验证为准。

---

# NestCam Live Watch8 V2 — Google Home 警报桥接版

> **新增**：利用 Android NotificationListenerService，读取手机 Google Home 已发出的 backyard 摄像头警报（需要用户授权）。识别人物、移动、动物、车辆、声音等文本标签，筛选/去重/本机事件历史，选择性用 Wear OS Data Layer 发送到 Watch 8。本功能不要求 Pub/Sub、Cloud Shell 或服务器。
>
> **重要区别**：人物/移动属于 SDM 官方开放的事件；动物、车辆、声音只根据 Google Home **实际发出的通知文字**处理，不意味着它们有可用的 SDM API。未收到 Google Home 的警报就无法转发。不可用于应急/人身安全唯一警报渠道。
>
> **配置**：Google Home → backyard 摄像头 → 事件 → 设定检测与通知；手机 NestCam V2 → 打开通知读取授权设置 → 允许 NestCam backyard 警报转发 → 启用 backyard 通知监听 → 需要时打开手表额外转发 → 在手表授权通知 → 点击手机的「发送手表测试警报」测试。防止双重提醒，手表额外转发默认关闭。
>
> **安全与隐私**：过滤 Google Home 的固定包名和摄像头名称；不读取与其他 App 有关的警报用于转发；仅发送事件类型、设备名与时间到配对手表；本机最多保存 50 条精简事件记录，不上传云端。不预置 OAuth Client Secret。
>
> **限制**：需要手机能够接收 Google Home 通知，并在 Android 设置中手动授予“通知使用权”。部分系统可能限制后台进程与通知，可因系统策略延迟/丢失。Google Home 原生通知/Google Wearable 通知镜像可能造成重复；若启用额外转发，应禁用其中一个渠道。只在收到匹配 `backyard` 名称和可识别类型的 Google Home 文本通知时触发，其他通知一律忽略。收到事件并不等于 Nest SDM Pub/Sub 事件已经启用。
>
> **独立 SDM 事件链路**：完整官方事件订阅需要 Google Cloud Pub/Sub 自建 Topic、订阅、授权的安全服务端或适当的受控接收器。2026-11-30 Google 托管 Topic 停用后必须使用自己的 GCP Topic。这一版尚**未**实现 Pub/Sub 云服务。
>
> **Google Home 专属**：活动区域、动物车辆检测选择、录像历史、Nest Aware、摄像头其他硬件设置继续在 Google Home 管理；官方 SDM 电池版没有开放这些第三方控制接口。

---

# NestCam Live Watch8 V1 — 手机 + Galaxy Watch 8

两个 APK 均从本仓库产生，无需 Cloud Shell、无需手动运行 Python。**这是首次集成的开发验证版：源码含真实 Nest SDM API 和 WebRTC 信令/解码代码，但尚未在用户的 backyard Nest Cam 和 Watch 8 真机上验证，不能保证第一次就播放成功。**

## 功能

- `mobile`：输入个人 Google OAuth Web Client ID 和 Client Secret（仅运行时输入，Android Keystore 本机加密）、Chrome 外部授权、从剪贴板粘贴回调 URL（含 `code=`）、兑换/自动刷新 Token、`devices.list`、Nest 手机 WebRTC 播放、自动延长 WebRTC 会话、Wear Data Layer 信令服务
- `wear`：Wear OS 设备列表、自动选择 backyard、手表本机 H.264 WebRTC 预览、连接状态、暂停、重连、通过配对手机请求直播和每三分钟延长会话
- `shared`：Google Nest WebRTC SDP 兼容处理、接收音视频轨道、SurfaceViewRenderer

## 一次上传 GitHub（在网页操作）

1. GitHub 新建空仓库，建议名称 `NestCam_Live_Watch8_V1`。
2. 解压本 ZIP，将**ZIP 内所有文件夹和隐藏的 `.github` 目录**上传到仓库根目录。GitHub 网页无法直接将 ZIP 作为工作流源码解压，需解压后上传里面的文件。
3. 点击 Actions → **Build NestCam Mobile + Watch8** → Run workflow（首次需允许 Actions），也可推送 main 自动触发。
4. 成功后下载两个 Actions Artifacts：`nestcam-mobile-debug-apk` 与 `nestcam-watch8-debug-apk`。
5. 安装两个 APK：`mobile-debug.apk` 手机安装；`wear-debug.apk` 安装到 Galaxy Watch 8。两个安装包使用相同的 applicationId 和相同签名（Google Wear Data Layer 的要求），分别安装在手机和手表上；它们不会覆盖 Google Home。

**构建环境**：AGP 8.9.2、Gradle 8.11.1、JDK 17、Android SDK 35（targetSdk 34）、Google Play services Wearable 20.0.1、Maven Central WebRTC 150.7871.08。

## 初次授权（不再使用 Cloud Shell）

1. 手机上打开 NestCam Live，点“配置 OAuth”。粘贴现有 Google Cloud 项目内 **Web 应用 OAuth Client ID** 和新创建的 Client Secret。不要将密钥写入任何 GitHub 文件。
2. 点“打开 Google Nest 授权”：用 Chrome 浏览器确认 backyard 的直播权限。回调目标为你此前配置的 `https://www.google.com`。
3. 完成后在 Chrome 地址栏复制**完整回调 URL**，回到手机 App，点“粘贴授权回调网址 / code”，确认粘贴；App 本机将 code 兑换令牌并调用 `devices.list`。
4. 在手机上确认摄像头并可选择播放，随后打开 Watch 8 App。手表与手机必须通过 Google Play Services Wearable Data Layer 能够通信，手表自身需要可用的网络连接。Watch 端不保存 Client Secret，不接收 Access Token。

**授权码一次性且短期有效**：如果 `invalid_grant`，回到第二步重新授权。Google OAuth Testing 状态下刷新令牌可能约 7 天失效，此时需要重新授权。**不要发送 code、Client Secret、Access Token 或 Refresh Token**。

## 当前范围和已知限制

- Google SDM WebRTC SDP 必须是 Unified Plan 且 m=audio / m=video / m=application 顺序，含 `recvonly` 的 Opus 音频、H264 视频和数据通道；由源码生成。
- **必须有配对的手机处理 OAuth/SDM API，手表不是完全独立云端客户端**。手表视频流在手表直接建立，不通过将手机画面截图转发。
- 数据层消息依赖 Google Play Services、配对与两设备联通性；Android 后台限制可能打断服务。这是开发版，尚无长期常驻前台服务或可靠断线重连保障。
- Nest Cam 电池版长期连接电源时才可延长直播；最初五分钟，App 会尝试延长。自动续期不代表 Google 保证无限播放。
- 人物/移动侦测震动提醒需要另外启用 Google Cloud Pub/Sub 与通知链路，**本 V1 不包含事件提醒**，以免误导。
- 用户过去配置的 OAuth Web 客户端使用 `https://www.google.com` 回调，V1 暂时需要复制 URL；正式产品应改为有自己可控域名或可信后端的 HTTPS 回调，以避免不便与潜在泄露。
- 该版本以手机和手表同时在线为设计前提。需在真实摄像头上测试 WebRTC 和 SDP 兼容。若编译失败，保存 GitHub Actions 日志中的第一条编译错误再修复；不要上传密钥。
- 由于开发环境没有 Android SDK/Gradle 构建服务，这里提供可编译项目与 CI 配置，**未在本地编译出 APK**。

## 重要安全说明

- Google Web OAuth 客户端的 `Client Secret` 属于**机密**，不得硬编码进公开 APK 或仓库；此个人版只让用户安装后自行输入，保存在 AndroidKeyStore 加密的本地存储中。
- Android 应用包含 secret 即使加密存储，也不等于强信任的服务器凭证保管；如果未来多人使用或共享设备，务必迁至服务端，并使用正式 HTTPS 回调及受控令牌服务。
- 关闭手机应用不会永久撤销授权；需要时可在 Google Partner Connections Manager 撤销授权。
- Google 官方文档：
  - https://developers.google.com/nest/device-access/api/camera-battery
  - https://developers.google.com/nest/device-access/traits/device/camera-live-stream
  - https://developers.google.com/nest/device-access/authorize
  - https://developer.android.com/training/wearables/data/overview
