package com.nestcam.watch8.wear;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/** Background Wear OS alert handler; no camera tokens are sent to the watch. */
public final class WatchAlertService extends WearableListenerService {
    public static final String PATH="/nestcam/v2/alert";
    private static final String CHANNEL="nestcam_watch_alert_v2";
    @Override public void onMessageReceived(MessageEvent event){
        if(!PATH.equals(event.getPath()) || event.getData().length>4096)return;
        try{
            JSONObject alert=new JSONObject(new String(event.getData(), StandardCharsets.UTF_8));
            String type=alert.optString("type","motion");
            String camera=alert.optString("camera","backyard");
            if(camera.length()>45)camera=camera.substring(0,45);
            boolean test=alert.optBoolean("test",false);
            String label=label(type);
            getSharedPreferences("watch_alerts",MODE_PRIVATE).edit()
               .putString("last",(test?"测试 · ":"")+camera+" · "+label)
               .putLong("time",System.currentTimeMillis()).apply();
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm==null)return;
            NotificationChannel ch=new NotificationChannel(CHANNEL,"NestCam 监控警报",NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,250,160,350});
            nm.createNotificationChannel(ch);
            Intent intent=new Intent(this,WatchActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("camera_alert",label);
            PendingIntent pending=PendingIntent.getActivity(this,120,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification notification=new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle((test?"测试 · ":"")+camera+" · "+label)
                .setContentText("点击查看摄像头实时画面")
                .setContentIntent(pending).setAutoCancel(true).setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PRIVATE).build();
            nm.notify(2001,notification);
        }catch(Exception ignored){}
    }
    private static String label(String type){
        switch(type){case "person":return "发现人物";case "animal":return "发现动物";case "vehicle":return "发现车辆";
            case "sound":return "声音提醒";case "motion":return "检测到移动";default:return "测试提醒";}
    }
}
