package com.nestcam.watch8.wear;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.FrameLayout;
import com.google.android.gms.wearable.MessageClient;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.nestcam.watch8.shared.RtcViewer;
import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.RendererCommon;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class WatchActivity extends Activity implements MessageClient.OnMessageReceivedListener {
    private static final String REQ = "/nestcam/v1/request", RES = "/nestcam/v1/response";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicInteger counter = new AtomicInteger();
    private final List<Camera> cameras = new ArrayList<>();
    private TextView nameView, statusView;
    private SurfaceViewRenderer surface;
    private RtcViewer rtc;
    private String nodeId = "", sessionState = "";
    private String expected = "";
    private int selected = -1;
    private boolean active = false, paused = false;
    private Runnable keepAlive, retry;
    private FrameLayout videoFrame;
    private LinearLayout root, controls;
    private Button fullscreenButton;
    private boolean fullScreen=false;
    private boolean firstFrame=false;
    private TextView videoStatus;
    private static class Camera {String name,id;Camera(String n,String i){name=n;id=i;}}

    private int dp(float p){return (int)(p*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String label, int size, int color){
        TextView t=new TextView(this);t.setText(label);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER);
        return t;
    }
    private Button button(String s, LinearLayout parent, Runnable action){
        Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);
        b.setTextColor(Color.WHITE);b.setBackgroundTintList(ColorStateList.valueOf(0xff27415B));
        parent.addView(b,new LinearLayout.LayoutParams(0,dp(43),1));b.setOnClickListener(v->action.run());return b;
    }
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff08121E);getWindow().setNavigationBarColor(0xff08121E);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(0xff091521);
        root.setPadding(dp(17),dp(6),dp(17),dp(7));setContentView(root);
        nameView=text("NestCam · backyard",15,Color.WHITE);nameView.setSingleLine(true);
        root.addView(nameView,new LinearLayout.LayoutParams(-1,dp(28)));
        nameView.setOnClickListener(v->cycleCamera());
        statusView=text("连接配对手机中...",11,0xffA2BED8);
        root.addView(statusView,new LinearLayout.LayoutParams(-1,dp(27)));
        videoFrame=new FrameLayout(this);videoFrame.setBackgroundColor(0xff132335);
        LinearLayout.LayoutParams videoParams=new LinearLayout.LayoutParams(-1,0,1);videoParams.topMargin=dp(3);videoParams.bottomMargin=dp(4);
        root.addView(videoFrame,videoParams);
        surface=new SurfaceViewRenderer(this);videoFrame.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        videoStatus=text("连接监控画面中…",11,Color.WHITE);
        videoStatus.setBackgroundColor(0x99000000);
        videoFrame.addView(videoStatus,new FrameLayout.LayoutParams(-1,dp(27),Gravity.TOP));
        fullscreenButton=new Button(this);
        fullscreenButton.setText("⛶");fullscreenButton.setAllCaps(false);fullscreenButton.setTextSize(13);
        fullscreenButton.setTextColor(Color.WHITE);
        fullscreenButton.setPadding(0,0,0,0);
        fullscreenButton.setBackgroundTintList(ColorStateList.valueOf(0xcc27415b));
        // Bottom-center stays clickable on the circular Watch8 screen (top-right is clipped).
        videoFrame.addView(fullscreenButton,new FrameLayout.LayoutParams(dp(43),dp(35),Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM));
        fullscreenButton.setOnClickListener(v->setFullScreen(!fullScreen));
        rtc=new RtcViewer(this,surface,new RtcViewer.Listener(){
            @Override public void onOffer(String offer){
                if(selected < 0 || selected >= cameras.size()){status("请选择摄像头");return;}
                sessionState="starting";
                try{send("START",new JSONObject().put("device",cameras.get(selected).id).put("offer",offer));}
                catch(Exception e){status("直播请求失败");}
            }
            @Override public void onStatus(String state){
                status(state);
                if(!firstFrame)ui.post(()->{if(!firstFrame && videoStatus!=null){
                    videoStatus.setText(state);videoStatus.setVisibility(View.VISIBLE);
                }});
            }
            @Override public void onFirstFrame(){
                firstFrame=true;
                if(videoStatus!=null)videoStatus.setVisibility(View.GONE);
                status("正在播放直播");
            }
        });
        controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(controls,new LinearLayout.LayoutParams(-1,dp(43)));
        button("▶ 直播",controls,this::play);
        button("■ 停止",controls,this::stop);
        button("↻ 重连",controls,()->{stop();requestList(true);});
        nameView.setOnLongClickListener(v->{requestList(false);return true;});
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},106);
    }
    // Screen-only switch: keep the same SurfaceView, PeerConnection and SDM session.
    private void setFullScreen(boolean enabled){
        if(fullScreen==enabled)return;
        fullScreen=enabled;
        nameView.setVisibility(enabled?View.GONE:View.VISIBLE);
        statusView.setVisibility(enabled?View.GONE:View.VISIBLE);
        controls.setVisibility(enabled?View.GONE:View.VISIBLE);
        root.setPadding(enabled?0:dp(17),enabled?0:dp(6),enabled?0:dp(17),enabled?0:dp(7));
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,0,1);
        params.topMargin=enabled?0:dp(3);
        params.bottomMargin=enabled?0:dp(4);
        videoFrame.setLayoutParams(params);
        fullscreenButton.setText(enabled?"↙":"⛶");
        // Round Watch 8: fill the circular display; the outside edges are cropped.
        surface.setScalingType(enabled?RendererCommon.ScalingType.SCALE_ASPECT_FILL:
                RendererCommon.ScalingType.SCALE_ASPECT_FIT);
    }
    @Override public void onBackPressed(){
        if(fullScreen)setFullScreen(false);
        else super.onBackPressed();
    }
    private void status(String s){ui.post(()->{if(!paused)statusView.setText(s);});}
    @Override protected void onResume(){
        super.onResume();paused=false;
        String alert=getSharedPreferences("watch_alerts",MODE_PRIVATE).getString("last","");
        long when=getSharedPreferences("watch_alerts",MODE_PRIVATE).getLong("time",0L);
        if(!alert.isEmpty() && System.currentTimeMillis()-when<300000L)statusView.setText(alert);
        Wearable.getMessageClient(this).addListener(this)
            .addOnSuccessListener(unused -> requestList(true))
            .addOnFailureListener(e -> status("手表通信初始化失败"));
    }
    @Override protected void onPause(){
        paused=true;
        stop();
        Wearable.getMessageClient(this).removeListener(this);
        super.onPause();
    }
    private void requestList(boolean autoPlay){
        status("读取手机摄像头列表...");
        try{send("LIST",new JSONObject().put("auto",autoPlay));}catch(Exception e){status("无法连接手机");}
    }
    private void send(String cmd,JSONObject params){
        try{
            params.put("cmd",cmd);params.put("req",Integer.toString(counter.incrementAndGet()));
            String str=params.toString();
            Wearable.getNodeClient(this).getConnectedNodes()
                .addOnSuccessListener(nodes->{
                    if(nodes.isEmpty()){status("未连接手机：检查蓝牙/Wi-Fi 和手机 App");return;}
                    Node n=nodes.get(0);nodeId=n.getId();
                    Wearable.getMessageClient(this).sendMessage(n.getId(),REQ,str.getBytes(StandardCharsets.UTF_8))
                        .addOnFailureListener(e->status("发送失败: "+e.getClass().getSimpleName()));
                })
                .addOnFailureListener(e->status("手表配对通信失败"));
        }catch(Exception e){status("命令构造失败");}
    }
    private void cycleCamera(){
        if(cameras.isEmpty()){requestList(false);return;}
        selected=(selected+1)%cameras.size();
        nameView.setText(cameras.get(selected).name+"  ▾");
        stop();play();
    }
    private void play(){
        if(selected<0){requestList(true);return;}
        if(active)return;
        active=true;
        firstFrame=false;
        videoStatus.setText("连接监控画面中…");
        videoStatus.setVisibility(View.VISIBLE);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        rtc.start();
    }
    private void stop(){
        if(retry!=null)ui.removeCallbacks(retry);
        if(keepAlive!=null)ui.removeCallbacks(keepAlive);
        retry=null;keepAlive=null;
        boolean wasActive=active;active=false;
        sessionState="";
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(rtc!=null)rtc.stop();
        firstFrame=false;
        if(videoStatus!=null){videoStatus.setText("已停止，点击直播播放");videoStatus.setVisibility(View.VISIBLE);}
        if(wasActive){try{send("STOP",new JSONObject());}catch(Exception ignored){}}
    }
    @Override public void onMessageReceived(MessageEvent event){
        if(!RES.equals(event.getPath()))return;
        byte[] msg=event.getData();
        if(msg.length>100000)return;
        final String payload=new String(msg,StandardCharsets.UTF_8);
        ui.post(()->handle(payload));
    }
    private void handle(String raw){
        if(paused)return;
        try{
            JSONObject response=new JSONObject(raw);
            String cmd=response.optString("cmd");
            if(!response.optBoolean("ok",false)){
                status("Nest: " + response.optString("message","连接失败"));
                if("START".equals(cmd)) {active=false;getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
                if("EXTEND".equals(cmd) && active) {
                    stop();
                    retry=()->{if(!paused)play();};
                    ui.postDelayed(retry,3000);
                }
                return;
            }
            if("LIST".equals(cmd)){
                JSONArray list=response.optJSONArray("devices");
                if(list==null || list.length()==0){status("无可用摄像头：先在手机授权并刷新");return;}
                String previous = selected>=0 && selected<cameras.size() ? cameras.get(selected).id : "";
                cameras.clear();int best=0;
                for(int i=0;i<list.length();i++){
                    JSONObject d=list.getJSONObject(i);
                    Camera camera=new Camera(d.getString("name"),d.getString("id"));
                    if(camera.name.equalsIgnoreCase("backyard") || camera.id.equals(previous))best=i;
                    cameras.add(camera);
                }
                selected=best;nameView.setText(cameras.get(selected).name+"  ▾");
                status("发现 "+cameras.size()+" 台摄像头");
                if(!active)play();
            }else if("START".equals(cmd)){
                if(!active)return;
                rtc.setAnswer(response.getString("answer"));
                sessionState="streaming";
                scheduleExtend();
            }else if("EXTEND".equals(cmd)){
                if(active){status("直播续期成功");scheduleExtend();}
            }else if("STOP".equals(cmd)){status("已停止");}
        }catch(Exception e){status("响应格式异常");}
    }
    private void scheduleExtend(){
        if(keepAlive!=null)ui.removeCallbacks(keepAlive);
        if(!active)return;
        keepAlive=()->{
            if(!active)return;
            status("正在延长直播...");
            try{send("EXTEND",new JSONObject());}catch(Exception e){status("续期请求失败");}
        };
        ui.postDelayed(keepAlive,180000);
    }
    @Override protected void onNewIntent(android.content.Intent intent){
        super.onNewIntent(intent);setIntent(intent);
        if(intent!=null && intent.hasExtra("camera_alert"))status("警报 · "+intent.getStringExtra("camera_alert"));
    }
    @Override protected void onDestroy(){
        stop();
        if(rtc!=null)rtc.release();
        super.onDestroy();
    }
}
