package com.nestcam.watch8.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Forwards only Google Home's already-generated notifications; NOT SDM Pub/Sub. */
public final class AlertHub {
    private AlertHub() {}
    public static final String PATH = "/nestcam/v2/alert";
    public static final String HOME_PACKAGE = "com.google.android.apps.chromecast.app";
    private static final String STORE = "nestcam_alerts_v2";
    public static SharedPreferences prefs(Context c){ return c.getApplicationContext().getSharedPreferences(STORE,Context.MODE_PRIVATE); }
    public static boolean setting(Context c,String key,boolean fallback){return prefs(c).getBoolean(key,fallback);}
    public static void set(Context c,String key,boolean value){prefs(c).edit().putBoolean(key,value).apply();}
    public static String camera(Context c){return prefs(c).getString("camera_name","backyard").trim();}
    public static void setCamera(Context c,String camera){ prefs(c).edit().putString("camera_name",camera.trim()).apply();}

    /** Require source notification to mention selected camera. Avoid relaying unrelated devices. */
    public static String detect(String text){
        String s = text.toLowerCase(Locale.ROOT);
        if (any(s,"person","people","有人","人物","检测到人","persona","personas","alguien"))return "person";
        if (any(s,"animal","宠物","动物","mascota","perro","gato","pet detected","pets"))return "animal";
        if (any(s,"vehicle","车辆","汽车","vehículo","vehiculo","coche","car detected"))return "vehicle";
        if (any(s,"sound","noise","声音","噪音","sonido","ruido"))return "sound";
        if (any(s,"motion","movement","moving","移动","活动","运动","movimiento","movim"))return "motion";
        return "";
    }
    private static boolean any(String s,String... terms){for(String x:terms)if(s.contains(x))return true;return false;}
    public static String label(String type){
        switch(type){case "person":return "发现人物";case "animal":return "发现动物";case "vehicle":return "发现车辆";case "sound":return "声音提醒";case "motion":return "检测到移动";default:return "测试提醒";}
    }
    public static boolean accepted(Context ctx,String type,String text){
        String camera = camera(ctx);
        return setting(ctx,"enabled",false) && !type.isEmpty() && setting(ctx,"type_"+type, true)
            && !camera.isEmpty() && text.toLowerCase(Locale.ROOT).contains(camera.toLowerCase(Locale.ROOT));
    }
    public static synchronized boolean recordAndSend(Context ctx,String type,String cameraName,String detail,boolean isTest){
        SharedPreferences p=prefs(ctx);long now=System.currentTimeMillis();
        // Same type from one camera within 30s is normally one Google Home event posted more than once.
        String key = type+":"+cameraName.toLowerCase(Locale.ROOT);
        if (!isTest && key.equals(p.getString("last_key","")) && now-p.getLong("last_time",0)<30000L)return false;
        p.edit().putString("last_key",key).putLong("last_time",now).apply();
        try {
            JSONArray old=new JSONArray(p.getString("history","[]"));
            JSONArray list=new JSONArray();
            JSONObject item=new JSONObject().put("type",type).put("camera",cameraName)
                .put("detail",detail.length()>120?detail.substring(0,120):detail).put("time",now).put("test",isTest);
            list.put(item);
            for(int i=0;i<old.length()&&i<49;i++){list.put(old.getJSONObject(i));}
            p.edit().putString("history",list.toString()).apply();
            if(setting(ctx,"forward_watch",false)){
                // Intentionally no sensitive keys, camera stream credentials or home notification extras on wire.
                JSONObject safe=new JSONObject().put("type",type).put("camera",cameraName).put("time",now).put("test",isTest);
                byte[] payload=safe.toString().getBytes(StandardCharsets.UTF_8);
                Wearable.getNodeClient(ctx.getApplicationContext()).getConnectedNodes().addOnSuccessListener(nodes->{
                    for(Node n:nodes)Wearable.getMessageClient(ctx.getApplicationContext()).sendMessage(n.getId(),PATH,payload);
                });
            }
            return true;
        }catch(Exception e){return false;}
    }
    public static String history(Context c){
        try{
            JSONArray list=new JSONArray(prefs(c).getString("history","[]"));
            if(list.length()==0)return "暂无警报记录。请先在 Google Home 开启摄像头通知。";
            java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("MM-dd HH:mm:ss",Locale.getDefault());
            StringBuilder out=new StringBuilder();
            for(int i=0;i<list.length()&&i<30;i++){
                JSONObject item=list.getJSONObject(i);
                out.append(fmt.format(new java.util.Date(item.optLong("time")))).append("   ")
                    .append(item.optBoolean("test")?"[测试] ":"")
                    .append(item.optString("camera")).append(" · ").append(label(item.optString("type"))).append("\n");
            }
            return out.toString();
        }catch(Exception e){return "记录读取失败";}
    }
}
