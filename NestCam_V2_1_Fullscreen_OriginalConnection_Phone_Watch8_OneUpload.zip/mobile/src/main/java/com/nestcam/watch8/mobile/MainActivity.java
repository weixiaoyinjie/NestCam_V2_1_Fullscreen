package com.nestcam.watch8.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.provider.Settings;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.Locale;
import com.nestcam.watch8.shared.RtcViewer;
import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.RendererCommon;
import java.time.Instant;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private NestApi api;
    private TextView state;
    private Spinner cameraSelector;
    private SurfaceViewRenderer surface;
    private RtcViewer rtc;
    private final ArrayList<JSONObject> cameras = new ArrayList<>();
    private String session = "", streamingDevice = "";
    private Runnable extension;
    private LinearLayout content;
    private ScrollView scroll;
    private FrameLayout videoFrame;
    private TextView videoStatus;
    private Button fullButton;
    private boolean fullScreen = false;
    private boolean firstFrame = false;
    private static final int IMMERSIVE_FLAGS = View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10,18,29));
        getWindow().setNavigationBarColor(Color.rgb(10,18,29));
        api = new NestApi(this);
        buildUi();
    }
    private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    private TextView text(String s, int sp, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(sp);
        v.setPadding(0,dp(6),0,dp(6)); return v;
    }
    private Button button(String s, LinearLayout box, Runnable action) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(ColorStateList.valueOf(0xff243C5A));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(47));p.bottomMargin=dp(6);
        box.addView(b,p);b.setOnClickListener(v->action.run());return b;
    }
    private void title(String s) { content.addView(text(s,16,0xffD7E8FA)); }
    private void buildUi() {
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xff0C1521);
        content=new LinearLayout(this);content.setPadding(dp(17),dp(8),dp(17),dp(32));content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);setContentView(scroll);
        TextView heading=text("NestCam Live · 手机控制台",21,Color.WHITE);heading.setGravity(Gravity.CENTER);
        content.addView(heading);
        state=text("准备就绪。首次使用请填写 OAuth Client ID 与 Secret。",13,0xffB5CCE0);
        content.addView(state);
        title("① 授权与摄像头");
        button("配置 OAuth（首次一次）",content,this::configure);
        button("打开 Google Nest 授权",content,()->{
            try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(api.authorizationUrl()))); }
            catch(Exception ex){ status(ex.getMessage()); }
        });
        button("粘贴授权回调网址 / code",content,this::pasteAuth);
        button("刷新摄像头列表（自动检测）",content,this::refresh);
        cameraSelector=new Spinner(this);
        cameraSelector.setBackgroundTintList(ColorStateList.valueOf(0xffA4BDD6));
        content.addView(cameraSelector,new LinearLayout.LayoutParams(-1,dp(48)));
        title("② 手机实时监控");
        // Keep a single renderer in its original parent: entering full screen must NOT
        // stop, re-offer, or detach the WebRTC stream (avoids the black SDP screen).
        videoFrame=new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams videoParams=new LinearLayout.LayoutParams(-1,dp(236));
        videoParams.bottomMargin=dp(10);
        content.addView(videoFrame,videoParams);
        surface=new SurfaceViewRenderer(this);
        videoFrame.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        videoStatus=text("点击播放，等待监控画面…",13,Color.WHITE);
        videoStatus.setBackgroundColor(0x99000000);
        videoStatus.setPadding(dp(8),dp(4),dp(8),dp(4));
        FrameLayout.LayoutParams hintParams=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        videoFrame.addView(videoStatus,hintParams);
        fullButton=new Button(this);
        fullButton.setText("⛶ 全屏");fullButton.setTextSize(12);fullButton.setAllCaps(false);
        fullButton.setTextColor(Color.WHITE);
        fullButton.setBackgroundTintList(ColorStateList.valueOf(0xcc243c5a));
        FrameLayout.LayoutParams fullParams=new FrameLayout.LayoutParams(dp(85),dp(45),Gravity.TOP|Gravity.END);
        videoFrame.addView(fullButton,fullParams);
        fullButton.setOnClickListener(v->setFullScreen(!fullScreen));
        // Rotation / system-bar changes can resize the scroll view without rebuilding RTC.
        scroll.addOnLayoutChangeListener((v,left,top,right,bottom,oldLeft,oldTop,oldRight,oldBottom)->{
            if(fullScreen)updateFullscreenVideoHeight();
        });
        rtc=new RtcViewer(this,surface,new RtcViewer.Listener(){
            @Override public void onOffer(String offer){
                if(cameras.isEmpty() || cameraSelector.getSelectedItemPosition()<0){status("没有摄像头，请先刷新列表");return;}
                JSONObject d=cameras.get(cameraSelector.getSelectedItemPosition());
                String selected=d.optString("name");
                status("正在请求 Nest WebRTC 直播...");
                execute(()->api.start(selected,offer),answer->{
                    streamingDevice=selected;session=answer.optString("mediaSessionId");
                    rtc.setAnswer(answer.optString("answerSdp"));
                    scheduleExtend(answer.optString("expiresAt"));
                });
            }
            @Override public void onStatus(String s){
                status(s);
                if(!firstFrame)ui.post(()->{if(!firstFrame && videoStatus!=null){
                    videoStatus.setText(s);videoStatus.setVisibility(View.VISIBLE);
                }});
            }
            @Override public void onFirstFrame(){
                firstFrame=true;
                if(videoStatus!=null)videoStatus.setVisibility(View.GONE);
                status("监控画面已显示");
            }
        });
        button("▶ 手机播放实时视频",content,()->{
            if(cameras.isEmpty()) {status("先点刷新摄像头列表");return;}
            if(!session.isEmpty()) stopPhone();
            firstFrame=false;
            videoStatus.setVisibility(View.VISIBLE);
            videoStatus.setText("连接 Nest 摄像头中…");
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            rtc.start();
        });
        button("■ 停止播放",content,this::stopPhone);
        title("③ Galaxy Watch 8");
        content.addView(text("在已配对的 Watch 8 上安装手表 APK，打开后即可请求本机直播。手机负责令牌、SDM API 和直播续期；画面由手表自身解码。",13,0xffB5CCE0));
        button("检查手表连接",content,()->com.google.android.gms.wearable.Wearable.getNodeClient(this)
            .getConnectedNodes().addOnSuccessListener(nodes -> status("已连接 Wear OS 节点: " + nodes.size()))
            .addOnFailureListener(e->status("手表连接检查失败："+e.getClass().getSimpleName())));
        title("④ backyard 监控预警 · Google Home 通知转发");
        content.addView(text("无需 Cloud Shell：先在 Google Home 给 backyard 开启移动/人物通知。本功能只监听 Google Home 已发出的系统通知，不是 SDM 云端事件服务。请在下方授予一次通知读取权限。",13,0xffB5CCE0));
        button("打开通知读取授权设置",content,()->{
            try{startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}
            catch(Exception ex){status("无法打开通知授权设置："+ex.getMessage());}
        });
        button("打开 Google Home · 设置事件类型/活动区域",content,()->{
            Intent launch=getPackageManager().getLaunchIntentForPackage(AlertHub.HOME_PACKAGE);
            if(launch!=null)startActivity(launch);
            else status("请安装 Google Home 并允许它发送摄像头通知");
        });
        button("检查监控警报权限",content,()->status(alertAccessGranted()
            ?"已授予 Google Home 通知读取权限；请确认 Google Home 已为 backyard 开启警报"
            :"尚未授予通知读取权限，请打开设置并开启 NestCam backyard 警报转发"));
        addAlertToggle("启用 backyard 通知监听", "enabled",false);
        addAlertToggle("转发到 Watch 8（避免重复提醒，默认关闭）", "forward_watch",false);
        addAlertToggle("人物出现", "type_person",true);
        addAlertToggle("画面移动", "type_motion",true);
        addAlertToggle("动物（仅 Google Home 推送时）", "type_animal",true);
        addAlertToggle("车辆（仅 Google Home 推送时）", "type_vehicle",true);
        addAlertToggle("声音（仅 Google Home 推送时）", "type_sound",true);
        button("匹配摄像头名称（默认 backyard）",content,()->field("匹配 Google Home 通知中的摄像头名",false,AlertHub.camera(this),name->{
            if(name.isEmpty())status("摄像头名不能为空");else{AlertHub.setCamera(this,name);status("只监听包含「"+name+"」的 Google Home 警报");}
        }));
        button("发送手表测试警报（非真实侦测）",content,()->{
            boolean ok=AlertHub.recordAndSend(this,"test",AlertHub.camera(this),"用户主动发起测试",true);
            status(ok?"测试记录已保存；若开启转发，请在 Watch 8 查看测试通知":"测试记录写入失败");
        });
        button("查看最近 30 条警报",content,()->new AlertDialog.Builder(this)
            .setTitle("backyard 最近警报（仅存手机）").setMessage(AlertHub.history(this))
            .setPositiveButton("关闭",null).show());
        content.addView(text("注意：Google Home 通知本来就会出现在手机/手表，重复转发可能产生两条提醒。已默认关闭额外手表通知；只有你明确开启才转发。Google Home 的事件录像、活动区域和订阅设置仍由官方 App 管理。",12,0xff8BA5BE));
        content.addView(text("安全：本 App 不预装密钥；你输入的 Client Secret、Token 会由 Android Keystore 在手机本地加密。授权使用外部 Chrome 浏览器，不使用 WebView。",12,0xff8BA5BE));
        button("清除本机全部授权信息",content,()->new AlertDialog.Builder(this)
            .setTitle("确认清除？").setMessage("删除本机保存的 Client ID、Secret 和访问令牌，不会删除 Google Cloud 项目。")
            .setNegativeButton("取消",null).setPositiveButton("清除",(d,w)->{stopPhone();api.clear();cameras.clear();state.setText("已清除本机授权信息");}).show());
    }
    /** Full-screen is a pure layout change, never a new Nest/SDP/WebRTC connection. */
    private void setFullScreen(boolean enable){
        if(fullScreen==enable)return;
        fullScreen=enable;
        if(enable){
            // Hide non-video controls, but keep the existing SurfaceViewRenderer attached.
            for(int i=0;i<content.getChildCount();i++){
                View child=content.getChildAt(i);
                if(child!=videoFrame)child.setVisibility(View.GONE);
            }
            content.setPadding(0,0,0,0);
            fullButton.setText("退出全屏");
            scroll.scrollTo(0,0);
            getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE_FLAGS);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            scroll.post(this::updateFullscreenVideoHeight);
        }else{
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            getWindow().getDecorView().setSystemUiVisibility(0);
            for(int i=0;i<content.getChildCount();i++){
                content.getChildAt(i).setVisibility(View.VISIBLE);
            }
            content.setPadding(dp(17),dp(8),dp(17),dp(32));
            fullButton.setText("⛶ 全屏");
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,dp(236));
            params.bottomMargin=dp(10);
            videoFrame.setLayoutParams(params);
            scroll.post(()->scroll.scrollTo(0,0));
        }
        // Avoid cropping image on a landscape phone; black sidebars only if unavoidable.
        surface.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
    }
    private void updateFullscreenVideoHeight(){
        if(!fullScreen || scroll==null || videoFrame==null)return;
        int height=scroll.getHeight();
        if(height<=0)return;
        ViewGroup.LayoutParams lp=videoFrame.getLayoutParams();
        if(lp.height!=height){
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,height);
            videoFrame.setLayoutParams(params);
        }
    }
    @Override public void onConfigurationChanged(Configuration configuration){
        super.onConfigurationChanged(configuration);
        if(fullScreen)scroll.post(this::updateFullscreenVideoHeight);
    }
    @Override public void onBackPressed(){
        if(fullScreen)setFullScreen(false);
        else super.onBackPressed();
    }

    private boolean alertAccessGranted(){
        String raw=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        if(raw==null)return false;
        String expected=new ComponentName(this,HomeAlertListener.class).flattenToString();
        for(String entry:raw.split(":"))if(entry.equalsIgnoreCase(expected))return true;
        return false;
    }
    private void addAlertToggle(String title,String key,boolean defaultValue){
        Switch sw=new Switch(this);
        sw.setText(title);sw.setTextColor(Color.WHITE);sw.setTextSize(13);
        sw.setPadding(dp(5),dp(5),dp(5),dp(5));
        sw.setChecked(AlertHub.setting(this,key,defaultValue));
        sw.setOnCheckedChangeListener((button,isChecked)->{
            AlertHub.set(this,key,isChecked);
            if("forward_watch".equals(key)&&isChecked)status("已请求向 Watch 8 转发额外警报。若重复，请关闭原生 Google Home 手表同步或本开关。");
        });
        content.addView(sw,new LinearLayout.LayoutParams(-1,dp(45)));
    }
    private void status(String s){ ui.post(()->state.setText(s)); }
    private interface Task { JSONObject run() throws Exception; }
    private interface Done { void run(JSONObject v); }
    private void execute(Task task,Done done) {
        io.execute(()->{try{JSONObject r=task.run();ui.post(()->done.run(r));}
          catch(Exception e){status("连接失败: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}});
    }
    private void field(String heading, boolean secret, String initial, java.util.function.Consumer<String> ok) {
        EditText edit=new EditText(this);edit.setTextColor(Color.BLACK);edit.setText(initial);
        edit.setSingleLine(!heading.contains("回调"));
        edit.setInputType(secret ? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD :
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(22),0,dp(22),0);box.addView(edit,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(this).setTitle(heading).setView(box).setNegativeButton("取消",null)
            .setPositiveButton("保存",(d,w)->ok.accept(edit.getText().toString().trim())).show();
    }
    private void configure() {
        field("OAuth Client ID",false,api.clientId(),id->{
            field("Client Secret（本机加密，不上传 GitHub）",true,"",secret->{
                try { api.configure(id,secret);status("OAuth 配置已安全保存在手机"); }
                catch(Exception e){status(e.getMessage());}
            });
        });
    }
    private void pasteAuth() {
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        String clip="";
        if(cb.hasPrimaryClip()) {
            ClipData data=cb.getPrimaryClip();
            if(data!=null&&data.getItemCount()>0) clip=data.getItemAt(0).coerceToText(this).toString();
        }
        field("粘贴含 code= 的回调 URL 或授权码",false,clip,value->{
            status("正在兑换 Google 授权令牌...");
            execute(()->{api.exchange(value);return new JSONObject().put("ok",true);},v->{status("授权成功，正在自动发现摄像头");refresh();});
        });
    }
    private void refresh(){
        io.execute(()->{
            try {
                JSONArray found=api.devices();
                ArrayList<JSONObject> next=new ArrayList<>();ArrayList<String> names=new ArrayList<>();
                int preferred=0;
                for(int i=0;i<found.length();i++){
                    JSONObject d=found.getJSONObject(i);
                    if(!NestApi.webrtc(d)) continue;
                    String n=NestApi.title(d);
                    if(n.equalsIgnoreCase("backyard")) preferred=next.size();
                    next.add(d);names.add(n+" · WebRTC");
                }
                int chosen=preferred;
                ui.post(()->{
                    cameras.clear();cameras.addAll(next);
                    ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);
                    cameraSelector.setAdapter(adapter);
                    if(!names.isEmpty()) cameraSelector.setSelection(chosen);
                    status(next.isEmpty()?"暂无支持 WEB_RTC 的摄像头。请核对 Google Home 授权":"发现 "+next.size()+" 台摄像头；手机和 Watch 8 可请求直播");
                });
            } catch(Exception e){status("获取设备失败："+e.getMessage());}
        });
    }
    private void scheduleExtend(String expiry) {
        if(extension!=null)ui.removeCallbacks(extension);
        if(session.isEmpty())return;
        long millis=220_000;
        try {millis=Instant.parse(expiry).toEpochMilli()-System.currentTimeMillis()-45_000;}catch(Exception ignored){}
        millis=Math.max(30_000,Math.min(millis,240_000));
        extension=()->{
            final String old=session,device=streamingDevice;
            if(old.isEmpty())return;
            execute(()->api.extend(device,old),json->{
                if(old.equals(session))scheduleExtend(json.optString("expiresAt"));
            });
        };
        ui.postDelayed(extension,millis);
    }
    private void stopPhone(){
        if(extension!=null)ui.removeCallbacks(extension);
        extension=null;
        String prior=session,dev=streamingDevice;
        session="";streamingDevice="";
        if(rtc!=null)rtc.stop();
        firstFrame=false;
        if(videoStatus!=null){videoStatus.setVisibility(View.VISIBLE);videoStatus.setText("已停止，点击播放继续监控");}
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(!prior.isEmpty())io.execute(()->{try{api.stop(dev,prior);}catch(Exception ignored){}});
    }
    @Override protected void onDestroy(){stopPhone();if(rtc!=null)rtc.release();io.shutdown();super.onDestroy();}
}
