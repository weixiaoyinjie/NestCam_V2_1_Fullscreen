package com.nestcam.watch8.mobile;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Optional notification bridge. Requires explicit user-granted notification access. */
public class HomeAlertListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn==null || !AlertHub.HOME_PACKAGE.equals(sbn.getPackageName()))return;
        Notification n=sbn.getNotification();
        if(n==null || (n.flags & Notification.FLAG_GROUP_SUMMARY)!=0)return;
        Bundle extras=n.extras;
        if(extras==null)return;
        StringBuilder text=new StringBuilder();
        for(String key:new String[]{Notification.EXTRA_TITLE,Notification.EXTRA_TEXT,Notification.EXTRA_BIG_TEXT,Notification.EXTRA_SUB_TEXT}){
            CharSequence value=extras.getCharSequence(key);
            if(value!=null)text.append(value).append(' ');
        }
        String content=text.toString().trim();
        if(content.isEmpty())return;
        String type=AlertHub.detect(content);
        if(!AlertHub.accepted(this,type,content))return;
        AlertHub.recordAndSend(this,type,AlertHub.camera(this),content,false);
    }
}
