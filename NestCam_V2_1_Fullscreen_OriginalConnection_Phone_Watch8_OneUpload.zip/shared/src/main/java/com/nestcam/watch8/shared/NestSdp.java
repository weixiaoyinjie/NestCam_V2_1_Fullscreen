package com.nestcam.watch8.shared;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Keep the SDP compliant with Google's camera requirements: audio/video/data in order,
 * only Opus audio, only H264 video, receive-only, and terminal CRLF. */
public final class NestSdp {
    private NestSdp() {}

    public static String restrict(String sdp) {
        String[] input = sdp.replace("\r\n", "\n").split("\n");
        List<List<String>> parts = new ArrayList<>();
        parts.add(new ArrayList<>());
        for (String s : input) {
            if (s.isEmpty()) continue;
            if (s.startsWith("m=")) parts.add(new ArrayList<>());
            parts.get(parts.size() - 1).add(s);
        }
        if (parts.size() != 4 || !parts.get(1).get(0).startsWith("m=audio ") ||
                !parts.get(2).get(0).startsWith("m=video ") ||
                !parts.get(3).get(0).startsWith("m=application ")) {
            throw new IllegalArgumentException("Nest 要求 SDP 含 audio/video/application，顺序固定");
        }
        List<String> output = new ArrayList<>(parts.get(0));
        output.addAll(filterMedia(parts.get(1), "opus"));
        output.addAll(filterMedia(parts.get(2), "h264"));
        output.addAll(parts.get(3));
        return String.join("\r\n", output) + "\r\n";
    }

    private static List<String> filterMedia(List<String> source, String codec) {
        Map<String, String> rtpmap = new HashMap<>();
        Map<String, String> apt = new HashMap<>();
        for (String s : source) {
            if (s.startsWith("a=rtpmap:")) {
                int pos = s.indexOf(' ');
                if (pos > 9) rtpmap.put(s.substring(9, pos), s.substring(pos + 1).toLowerCase());
            } else if (s.startsWith("a=fmtp:")) {
                int pos = s.indexOf(' ');
                if (pos > 7) {
                    String value = s.substring(pos + 1);
                    for (String segment : value.split(";")) {
                        segment = segment.trim();
                        if (segment.startsWith("apt=")) apt.put(s.substring(7, pos), segment.substring(4));
                    }
                }
            }
        }
        Set<String> keep = new HashSet<>();
        for (Map.Entry<String, String> e : rtpmap.entrySet()) {
            if (e.getValue().startsWith(codec + "/")) keep.add(e.getKey());
        }
        if (keep.isEmpty()) throw new IllegalArgumentException("此设备不提供 " + codec.toUpperCase() + " 编码");
        if ("h264".equals(codec)) {
            for (Map.Entry<String, String> e : apt.entrySet()) {
                if (keep.contains(e.getValue()) && rtpmap.getOrDefault(e.getKey(), "").startsWith("rtx/")) keep.add(e.getKey());
            }
        }
        String[] m = source.get(0).split(" ");
        StringBuilder mline = new StringBuilder(m[0]).append(" ").append(m[1]).append(" ").append(m[2]);
        for (int i = 3; i < m.length; i++) if (keep.contains(m[i])) mline.append(" ").append(m[i]);
        List<String> out = new ArrayList<>();
        out.add(mline.toString());
        boolean direction = false;
        for (int i = 1; i < source.size(); i++) {
            String line = source.get(i);
            if (line.startsWith("a=sendrecv") || line.startsWith("a=sendonly") || line.startsWith("a=recvonly") || line.startsWith("a=inactive")) {
                if (!direction) out.add("a=recvonly");
                direction = true;
            } else if (line.startsWith("a=rtpmap:") || line.startsWith("a=fmtp:") || line.startsWith("a=rtcp-fb:")) {
                int colon = line.indexOf(':');
                int space = line.indexOf(' ', colon);
                String pt = line.substring(colon + 1, space < 0 ? line.length() : space);
                if (keep.contains(pt) || "*".equals(pt)) out.add(line);
            } else {
                out.add(line);
            }
        }
        if (!direction) out.add("a=recvonly");
        return out;
    }
}
